import { DeclarationKind, DeclarationKindConfig } from './types.cjs';
export type NormalizedDeclarationKindConfig = Required<DeclarationKindConfig>;
export declare const DEFAULT_DECLARATION_KINDS: NormalizedDeclarationKindConfig;
export declare function normalizeDeclarationKind(declarationKind?: DeclarationKind | DeclarationKindConfig): NormalizedDeclarationKindConfig;
