import { DirectiveNode, EnumValueDefinitionNode, FieldDefinitionNode, FieldNode, FragmentDefinitionNode, FragmentSpreadNode, GraphQLInputObjectType, GraphQLNamedType, GraphQLObjectType, GraphQLOutputType, GraphQLSchema, GraphQLType, InlineFragmentNode, InputValueDefinitionNode, NamedTypeNode, NameNode, SelectionNode, SelectionSetNode, StringValueNode, TypeNode } from 'graphql';
import type { RawConfig } from './base-visitor.js';
import type { EnrichedFieldNode } from './selection-set-to-object.js';
import type { DeclarationKind, NormalizedScalarsMap, ParsedScalarsMap, ScalarsMap } from './types.js';
export declare const getConfigValue: <T = any>(value: T | null | undefined, defaultValue: T) => T;
export declare function quoteIfNeeded(array: string[], joinWith?: string): string;
export declare function block(array: string[] | null | undefined): string;
export declare function wrapWithSingleQuotes(value: string | number | NameNode, skipNumericCheck?: boolean): string;
export declare function breakLine(str: string): string;
export declare function indent(str: string, count?: number): string;
export declare function indentMultiline(str: string, count?: number): string;
export interface DeclarationBlockConfig {
    blockWrapper?: string;
    blockTransformer?: (block: string) => string;
    enumNameValueSeparator?: string;
    ignoreExport?: boolean;
}
export declare function transformComment(comment: string | StringValueNode | undefined | null, indentLevel?: number, disabled?: boolean): string;
export declare class DeclarationBlock {
    private _config;
    _decorator: string | null;
    _export: boolean;
    _name: string | NameNode | null;
    _kind: string | null;
    _methodName: string | null;
    _content: string | null;
    _block: string | null;
    _nameGenerics: string | null;
    _comment: string | null;
    _ignoreBlockWrapper: boolean;
    constructor(_config: DeclarationBlockConfig);
    withDecorator(decorator: string): DeclarationBlock;
    export(exp?: boolean): DeclarationBlock;
    asKind(kind: string): DeclarationBlock;
    withComment(comment: string | StringValueNode | null | undefined, disabled?: boolean): DeclarationBlock;
    withMethodCall(methodName: string, ignoreBlockWrapper?: boolean): DeclarationBlock;
    withBlock(block: string | null): DeclarationBlock;
    withContent(content: string): DeclarationBlock;
    withName(name: string | NameNode, generics?: string | null): DeclarationBlock;
    get string(): string;
}
export declare function getBaseTypeNode(typeNode: TypeNode): NamedTypeNode;
export declare function buildScalarsFromConfig(schema: GraphQLSchema | undefined, config: RawConfig, defaultScalarsMapping?: NormalizedScalarsMap, defaultScalarType?: string): ParsedScalarsMap;
export declare function buildScalars(schema: GraphQLSchema | undefined, scalarsMapping: ScalarsMap | undefined, defaultScalarsMapping?: NormalizedScalarsMap, defaultScalarType?: string | null): ParsedScalarsMap;
export declare function stripMapperTypeInterpolation(identifier: string): string;
export declare const OMIT_TYPE = "export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;";
export declare const REQUIRE_FIELDS_TYPE = "export type RequireFields<T, K extends keyof T> = Omit<T, K> & { [P in K]-?: NonNullable<T[P]> };";
/**
 * merge selection sets into a new selection set without mutating the inputs.
 */
export declare function mergeSelectionSets(selectionSet1: SelectionSetNode, selectionSet2: SelectionSetNode): SelectionSetNode;
export declare const getFieldNodeNameValue: (node: FieldNode) => string;
export declare function separateSelectionSet(selections: ReadonlyArray<SelectionNode>): {
    fields: EnrichedFieldNode[];
    spreads: FragmentSpreadNode[];
    inlines: InlineFragmentNode[];
};
export declare function getPossibleTypes(schema: GraphQLSchema, type: GraphQLType | null | undefined): GraphQLObjectType[];
/**
 * Check if a fragment declares variables, i.e. it uses fragment arguments
 * (`fragment A($size: Int!) on User`, graphql v17 `experimentalFragmentArguments`).
 */
export declare function hasFragmentVariables(node: FragmentDefinitionNode): boolean;
/**
 * Check if any of the directives are conditional i.e. `@skip` and `@include`
 */
export declare function hasConditionalDirectives(directives?: readonly DirectiveNode[]): boolean;
/**
 * Check if any of the directives are incremental i.e. `@defer`
 */
export declare function hasIncrementalDeliveryDirectives(directives?: readonly DirectiveNode[]): boolean;
type WrapModifiersOptions = {
    wrapOptional(type: string): string;
    wrapArray(type: string): string;
};
export declare function wrapTypeWithModifiers(baseType: string, type: GraphQLOutputType | GraphQLNamedType, options: WrapModifiersOptions): string;
export declare function removeDescription<T extends {
    description?: StringValueNode;
}>(nodes: readonly T[]): (T & {
    description: undefined;
})[];
export declare function wrapTypeNodeWithModifiers(baseType: string, typeNode: TypeNode): string;
/**
 * A @oneOf input with multiple fields is emitted as a union, which only a `type` alias can declare,
 * so the configured declaration kind applies only when there is a single field.
 */
export declare function getOneOfInputDeclarationKind({ fieldCount, inputDeclarationKind, }: {
    fieldCount: number;
    inputDeclarationKind: DeclarationKind;
}): DeclarationKind;
export declare function isOneOfInputObjectType(namedType: GraphQLNamedType | null | undefined): namedType is GraphQLInputObjectType;
export declare function groupBy<T>(array: Array<T>, key: (item: T) => string | number): {
    [key: string]: Array<T>;
};
export declare function flatten<T>(array: Array<Array<T>>): Array<T>;
export declare function unique<T>(array: Array<T>, key?: (item: T) => string | number): Array<T>;
/**
 * Memoizes `getSelectionSetCacheKey` per selection set node. Entries are dropped once the node's
 * document is no longer referenced.
 *
 * @internal Exported for tests only; not part of the public API.
 */
export declare const selectionSetCacheKeys: WeakMap<SelectionSetNode, string>;
/**
 * Builds a cache key describing a selection set as written: fragment spreads are referenced by
 * name rather than expanded, so the key stays linear in the size of the document even when
 * fragments are deeply nested and widely reused. The parts are sorted so the key does not depend
 * on selection order.
 *
 * Examples:
 * - `{ user { id name } }` becomes `user{id,name}` (the inner `{ id name }` becomes `id,name`)
 * - `{ id ...UserFields }` becomes `...UserFields,id` (the fragment is referenced by name, not
 *   expanded)
 * - `{ ... on Admin { role } }` becomes `... on Admin{role}`
 * - `{ me: user { id ...UserFields @include(if: $withFields) ... on Admin { role } } }` becomes
 *   `me@user{... on Admin{role},...UserFields @include(if: $withFields),id}`
 *
 * @internal Not part of the public API.
 */
export declare function getSelectionSetCacheKey(selectionSet: SelectionSetNode, seenFragments?: string[]): string;
export declare const getNodeComment: (node: FieldDefinitionNode | EnumValueDefinitionNode | InputValueDefinitionNode) => string;
/**
 * @description Utility function to print a TypeScript type that is `Maybe`.
 * We need this since some TypeScript types have special handling.
 * e.g. `unknown | null | undefined` is treated as `unknown`
 *
 * Note: we currently have two types of handling nullable: `Maybe<T>` or `T | null | undefined`
 * This function only handles the latter case at the moment, but could be extended if needed.
 *
 * @param {Object} params
 * @param {string} params.type - The TypeScript type e.g. `any`, `unknown`, `string`, `Something`
 * @param {string} params.pattern - The pattern of the Maybe type. This is usually `T | null | undefined` or `T | null`
 * @returns {string} The TypeScript type as string
 */
export declare const printTypeScriptMaybeType: ({ type, pattern, }: {
    type: string;
    pattern: string;
}) => string;
export {};
